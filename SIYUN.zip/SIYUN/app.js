const app = {
    apiKey: localStorage.getItem('gemini_api_key') || '',
    
    init() {
        this.populateSelects();
        if (this.apiKey) {
            document.getElementById('api-key-input').value = this.apiKey;
            document.getElementById('api-key-status').style.display = 'block';
            document.getElementById('api-key-status').textContent = 'API 키가 로드되었습니다.';
            document.getElementById('api-key-status').style.color = '#10b981'; // green
        }
    },

    saveApiKey() {
        const input = document.getElementById('api-key-input');
        const key = input.value.trim();
        if (key) {
            this.apiKey = key;
            localStorage.setItem('gemini_api_key', key);
            document.getElementById('api-key-status').style.display = 'block';
            document.getElementById('api-key-status').textContent = 'API 키가 저장되었습니다.';
            document.getElementById('api-key-status').style.color = '#10b981';
        } else {
            alert('API 키를 입력해주세요.');
        }
    },

    navigate(viewId) {
        // Hide all views
        document.querySelectorAll('.view').forEach(el => el.classList.remove('active'));
        // Show target view
        document.getElementById(`view-${viewId}`).classList.add('active');
        
        // Update nav items
        document.querySelectorAll('.nav-item').forEach(el => {
            if (el.dataset.target === viewId) {
                el.classList.add('active');
            } else {
                el.classList.remove('active');
            }
        });
    },

    populateSelects() {
        // Messenger options
        const msgSelect = document.getElementById('messenger-received');
        appData.messengerReply.forEach((item, index) => {
            const opt = document.createElement('option');
            opt.value = index;
            opt.textContent = item.receivedMessage;
            msgSelect.appendChild(opt);
        });

        // Situational options
        const sitSelect = document.getElementById('situational-category');
        appData.situationalConversation.forEach((item, index) => {
            const opt = document.createElement('option');
            opt.value = index;
            opt.textContent = item.category;
            sitSelect.appendChild(opt);
        });
    },

    async getRealtimeCoaching() {
        const input = document.getElementById('realtime-situation');
        const resultBox = document.getElementById('realtime-result');
        const loadingBox = document.getElementById('realtime-loading');
        const btn = document.getElementById('btn-realtime');
        const text = input.value.trim();

        if (text === "") {
            alert("상황을 자세히 입력해주세요!");
            return;
        }
        
        if (!this.apiKey) {
            alert("상단의 [Gemini API 키 입력...] 칸에 발급받은 API 키를 넣고 저장해주세요!");
            return;
        }

        // Show loading state
        resultBox.style.display = 'none';
        loadingBox.style.display = 'block';
        btn.disabled = true;
        btn.style.opacity = '0.5';

        try {
            const prompt = `너는 외국인이나 전학생이 한국 학생과 친해질 수 있도록 돕는 커뮤니케이션 코치야. 
다음 사용자의 상황을 읽고, 어떻게 행동해야 할지 '적절한 타이밍', '추천 표현', '다음 행동'을 한국어로 작성해줘. 
친절하고 실용적인 조언을 해줘.

상황: "${text}"

출력은 반드시 아래 JSON 형식으로만 해줘:
{
  "timing": "타이밍에 대한 조언",
  "expression": "상대방에게 건넬 수 있는 추천 대사 1~2문장",
  "nextAction": "표현을 건넨 이후의 행동 요령"
}`;

            const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-flash:generateContent?key=${this.apiKey}`, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({
                    contents: [{ parts: [{ text: prompt }] }],
                    generationConfig: {
                        responseMimeType: "application/json"
                    }
                })
            });

            if (!response.ok) {
                throw new Error(`API 요청 실패 (${response.status}) - API 키가 올바른지 확인해주세요.`);
            }

            const data = await response.json();
            const textResponse = data.candidates[0].content.parts[0].text;
            
            // 파싱
            const result = JSON.parse(textResponse);

            document.getElementById('rt-timing').textContent = result.timing;
            document.getElementById('rt-expression').textContent = result.expression;
            document.getElementById('rt-nextaction').textContent = result.nextAction;

            loadingBox.style.display = 'none';
            resultBox.style.display = 'block';

        } catch (error) {
            console.error(error);
            alert("AI 호출 중 오류가 발생했습니다: " + error.message);
            loadingBox.style.display = 'none';
        } finally {
            btn.disabled = false;
            btn.style.opacity = '1';
        }
    },

    getMessengerReply() {
        const select = document.getElementById('messenger-received');
        const resultBox = document.getElementById('messenger-result');
        const container = document.getElementById('msg-recommendations');
        
        if (select.value === "") {
            alert("받은 메시지를 선택해주세요!");
            return;
        }

        const data = appData.messengerReply[select.value];
        container.innerHTML = ''; // Clear previous

        data.recommendations.forEach(rec => {
            const item = document.createElement('div');
            item.className = 'recommendation-item';
            item.innerHTML = `
                <div class="recommendation-text">${rec.text}</div>
                <div class="recommendation-nuance">💡 ${rec.nuance}</div>
            `;
            container.appendChild(item);
        });
        
        resultBox.style.display = 'block';
    },

    renderSituational() {
        const select = document.getElementById('situational-category');
        const resultBox = document.getElementById('situational-content');
        const tipsContainer = document.getElementById('sit-tips');
        const examplesContainer = document.getElementById('sit-examples');
        
        if (select.value === "") {
            resultBox.style.display = 'none';
            return;
        }

        const data = appData.situationalConversation[select.value];
        
        // Render tips
        tipsContainer.innerHTML = '';
        data.tips.forEach(tip => {
            const li = document.createElement('li');
            li.textContent = tip;
            li.style.marginBottom = '6px';
            tipsContainer.appendChild(li);
        });

        // Render examples
        examplesContainer.innerHTML = '';
        data.examples.forEach(ex => {
            const bubble = document.createElement('div');
            const isMe = ex.speaker === '나';
            bubble.className = `chat-bubble ${isMe ? 'chat-right' : 'chat-left'}`;
            bubble.innerHTML = `
                <div class="chat-speaker">${ex.speaker}</div>
                ${ex.text}
            `;
            examplesContainer.appendChild(bubble);
        });
        
        resultBox.style.display = 'block';
    },

    sendSimMessage() {
        const input = document.getElementById('sim-input');
        const text = input.value.trim();
        if (!text) return;

        const chatArea = document.getElementById('sim-chat-area');
        
        // User message
        const userBubble = document.createElement('div');
        userBubble.className = 'chat-bubble chat-right';
        userBubble.innerHTML = `<div class="chat-speaker">나</div>${text}`;
        chatArea.appendChild(userBubble);
        
        input.value = '';
        chatArea.scrollTop = chatArea.scrollHeight;

        // Simulate bot reply
        setTimeout(() => {
            const botBubble = document.createElement('div');
            botBubble.className = 'chat-bubble chat-left';
            
            // Simple logic for simulation
            let botReply = "오 그렇구나! 밥은 먹었어?";
            if (text.includes("안녕")) botReply = "응 안녕! 반가워ㅎㅎ";
            if (text.includes("밥")) botReply = "아직 안 먹었어! 같이 학식 먹으러 갈래?";
            
            botBubble.innerHTML = `<div class="chat-speaker">지훈</div>${botReply}`;
            chatArea.appendChild(botBubble);
            chatArea.scrollTop = chatArea.scrollHeight;
        }, 1000);
    }
};

// Initialize app on load
window.addEventListener('DOMContentLoaded', () => {
    app.init();
});
